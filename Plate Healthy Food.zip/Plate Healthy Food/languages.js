/*---------- SETTINGS TO TURKISH ----------*/
function settingsToTurkish() {
  /* NAVBAR SECTION SETTINGS */
  const headerLogo = document.querySelector(".header_logo");
  if (headerLogo) {
    headerLogo.style.marginRight = "0";
    headerLogo.style.marginLeft = "22rem";
  }

  /* SLIDER SECTION SETTINGS */
  const imageSections = document.querySelectorAll(".image-section img ");
  imageSections.forEach((element) => {
    element.style.marginLeft = "0";
    element.style.marginRight = "20rem";
  });

  const circle = document.querySelector(".circle");
  if (circle) {
    circle.style.transform = "translate(45%, -5%)";
  }

  const textSections = document.querySelectorAll(".text-section");
  textSections.forEach((element) => {
    element.style.paddingRight = "0";
    element.style.paddingLeft = "20rem";
  });

  const texts = document.querySelectorAll(".texts");
  texts.forEach((element) => {
    element.style.paddingLeft = "4rem";
    element.style.textAlign = "left";
  });

  const sliderTitles = document.querySelectorAll(".h2_text");
  sliderTitles.forEach((element) => {
    element.style.textAlign = "left";
  });

  const dots = document.querySelectorAll(".dot");
  dots.forEach((dot) => {
    dot.style.transform = "translate(10%, 70%)";
  });

  const navigation = document.querySelector(".navigation");
  if (navigation) {
    navigation.style.paddingLeft = "4rem";
    navigation.style.justifyContent = "flex-start";
  }

  /* ABOUT US SECTION SETTINGS */
  const aboutUsTxtItems = document.querySelectorAll(".about_us_texts li");
  aboutUsTxtItems.forEach((item) => {
    item.style.paddingRight = "0";
    item.style.paddingLeft = "35px";
  });

  const style = document.createElement("style");
  style.innerHTML = `
    .about_us_texts li::before {
      left: 0;
      right: auto;
    }
  `;
  document.head.appendChild(style);

  /* WHAT WE OFFER SETTINGS */
  const whatImgItems = document.querySelectorAll(".what_img");
  whatImgItems.forEach((item) => {
    item.style.transform = "translate(75%, -60%)";
  });

  /* HOW IT WORKS SETTINGS */
  const rowDivs = document.querySelectorAll(".row");
  rowDivs.forEach((div) => {
    const svg = div.querySelector("svg");
    if (svg) {
      svg.style.transform = "scaleX(1)";
    }
  });

  const howDotItems = document.querySelectorAll(".how_dot");
  howDotItems.forEach((item) => {
    item.style.transform = "translate(-100%, -80%)";
  });

  /* FEATURES SECTION SETTINGS */
  const positionImg1 = document.querySelector(".position_img_1");
  if (positionImg1) {
    positionImg1.style.transform = "translate(0%, 40%)";
  }

  const positionImg2 = document.querySelector(".position_img_2");
  if (positionImg2) {
    positionImg2.style.transform = "translate(40%, 50%)";
  }

  const positionImg3 = document.querySelector(".position_img_3");
  if (positionImg1) {
    positionImg3.style.transform = "translate(20%, 10%)";
  }

  const positionImg4 = document.querySelector(".position_img_4");
  if (positionImg4) {
    positionImg4.style.transform = "translate(120%, 50%)";
  }

  /* WHAT OUR CLIENTS SAY SECTION SETTINGS */
  const dashes = document.querySelector(".dashes");
  if (dashes) {
    dashes.style.marginRight = "0";
    dashes.style.marginLeft = "5rem";
  }

  const clientsSay = document.querySelector(".clients_say");
  if (clientsSay) {
    clientsSay.style.gap = "75px";
  }

  const clientsTitles = document.querySelector(".clients_titles");
  if (clientsTitles) {
    clientsTitles.style.padding = "70px";
  }

  /* FOOTER SECTION SETTINGS */
  const phoneLiItems = document.querySelectorAll(".phone li");
  phoneLiItems.forEach((item) => {
    item.style.marginLeft = "0";
    item.style.marginRight = "20px";
  });

  const mailLiItems = document.querySelectorAll(".mail li");
  mailLiItems.forEach((item) => {
    item.style.marginLeft = "0";
    item.style.marginRight = "14px";
  });

  /* FORM SECTION SETTINGS */
  const toggleButton = document.querySelector(".toggleButton");
  if (toggleButton) {
    toggleButton.style.transform = "translate(-100%, 100%)";
  }

  const formContainer = document.querySelector(".formContainer");
  if (formContainer) {
    formContainer.style.right = "0";
    formContainer.style.left = "auto";
    formContainer.style.transform = "translateX(100%)";
    formContainer.style.transition = "transform 0.5s linear";
  }

  toggleButton.addEventListener("click", () => {
    if (formContainer.style.transform === "translateX(-100%)") {
      formContainer.style.transform = "translateX(0)";
    } else {
      formContainer.style.transform = "translateX(-100%)";
    }
  });

  const formInputs = document.querySelectorAll("input, textarea");
  formInputs.forEach((input) => {
    input.style.direction = "ltr";
  });

  /* DARK MODE SETTINGS */
  const darkModeButton = document.querySelector(".dark");
  if (darkModeButton) {
    darkModeButton.style.transform = "translate(-100%, -100%)";
  }
}

/*---------- TRANSLATE TO TURKISH ----------*/
function translateToTurkish() {
  /* TRANSLATE NAVBAR */
  const navSpans = document.querySelectorAll(".nav_span");
  const navSpansTrTexts = ["Programlar", "Hakkımızda", "Müşteriler"];
  navSpans.forEach((element, index) => {
    element.textContent = navSpansTrTexts[index];
  });

  /* TRANSLATE SLIDER */
  const sliderTexts = document.querySelectorAll(".texts");
  const sliderTextstrTexts = [
    "PLATE'YE HOŞ GELDİNİZ",
    "Plate, dünyanın her yerine organik ve sağlıklı yiyeceklerin hızlı teslimatını sunar.",
    "Neden Plate'i Seçmelisiniz",
    "ÜLKE ÇAPINDA TESLİMAT",
    "Konforunuz için 200'den fazla şehirde yemek dağıtım hizmetimiz mevcuttur.",
    "Ülke Çapında Teslimat",
    "EN İYİ YEMEKLER VE MALZEMELER",
    "Plate, müşterilerimizin en iyi ve en lezzetli yiyecekleri yediğinden emin olmak için menüleri düzenli olarak günceller.",
    "Organik Maddeler",
    "MÜŞTERİLERİMİZ BİZE GÜVENİYOR",
    "Müşterilerimizin yorumları, yemek dağıtım hizmetimiz hakkında daha fazla bilgi edinmenin en iyi yoludur.",
    "Yorumlar ve Görüşler",
  ];
  sliderTexts.forEach((element, index) => {
    element.textContent = sliderTextstrTexts[index];
  });

  const slidertitles = document.querySelectorAll(".h2_text");
  const slidertitlesTrTexts = [
    "TESLİMAT HİZMETİ",
    "DESTEKLENEN KONUMLAR",
    "LEZZETLİ YEMEKLER",
    "OLUMLU YORUMLAR",
  ];
  slidertitles.forEach((element, index) => {
    element.textContent = slidertitlesTrTexts[index];
  });

  /* TRANSLATE ABOUT US */
  const aboutUsText = document.querySelectorAll(".about_us_txt");
  const aboutUsTextTrTexts = [
    "HAKKIMIZDA",
    "SAĞLIKLI YİYECEKLER LEZZETLİ OLABİLİR",
    "Plate, herkesin istediği sağlıklı yiyecekleri sipariş edebileceği güvenilir bir yemek servisi sağlayıcısı olarak 2013 yılında kurulmuştur.",
    "Menümüzden glutensiz yemekler seçin",
    "Her yemek için en taze malzemeler",
    "+2 kişi için sipariş verirken harika indirimler alın",
  ];
  aboutUsText.forEach((element, index) => {
    element.textContent = aboutUsTextTrTexts[index];
  });

  const readMoreBtnText = document.querySelectorAll(".read_more_btn");
  const readMoreBtnTextTrText = [
    "DAHA FAZLA",
    "DAHA FAZLA",
    "DAHA FAZLA",
    "DAHA FAZLA",
    "DAHA FAZLA",
  ];
  readMoreBtnText.forEach((element, index) => {
    element.textContent = readMoreBtnTextTrText[index];
  });

  /* TRANSLATE WHAT WE OFFER */
  const whatTexts = document.querySelectorAll(".what_txt");
  const whatTextsTrTexts = [
    "SUNDUKLARIMIZ",
    "GIDA PAKETLERİ",
    "DETOKS",
    "GÜNLÜK",
    "Güne enerji dolu başlamak için lezzetli ve hafif ama sağlıklı yiyecekler arıyorsanız en iyi seçim.",
    "DENGELİ",
    "GÜNLÜK",
    "Kahvaltı ve akşam yemeği dahil günlük dengeli menüye ihtiyacınız varsa, ihtiyacınız olan şey Dengeli pakettir!",
    "VEGAN",
    "GÜNLÜK",
    "Sağlıklı ve bitki bazlı yiyecekleri takdir eden vegan müşterilerimiz için özel menü geliştirildi.",
  ];
  whatTexts.forEach((element, index) => {
    element.textContent = whatTextsTrTexts[index];
  });

  const readMorePdf = document.querySelectorAll(".read_more_pdf");
  const readMorePdfTrTexts = [
    "MENÜYÜ AÇ (PDF)",
    "MENÜYÜ AÇ (PDF)",
    "MENÜYÜ AÇ (PDF)",
  ];
  readMorePdf.forEach((element, index) => {
    element.textContent = readMorePdfTrTexts[index];
  });

  /* TRANSLATE HOW IT WORKS */
  const howTexts = document.querySelectorAll(".how_txt");
  const howTextsTrTexts = [
    "NASIL ÇALIŞIR",
    "SAĞLIKLI BESLENME İÇİN 3 ADIM",
    "BİR YİYECEK PAKETİ SEÇİN",
    "Öncelikle en çok tercih ettiğiniz paketi seçin.",
    "MENÜNÜZÜ ÖZELLEŞTİRİN",
    "Bundan sonra menünüzü değiştirmekten ve özelleştirmekten çekinmeyin.",
    "BİR TESLİMAT ADRESİ VE SAATİ SEÇİN",
    "Son olarak, yemeğinizi nereye ve ne zaman teslim edeceğinizi bize bildirin",
  ];
  howTexts.forEach((element, index) => {
    element.textContent = howTextsTrTexts[index];
  });

  /* TRANSLATE FEATURES */
  const fraturesTexts = document.querySelectorAll(".features_txt");
  const fraturesTextsTrTexts = [
    "KALİTE",
    "En kaliteli yemekleri, içecekleri ve hizmeti aldığınızdan emin olmak için en iyi tedarikçilerle çalışıyoruz.",
    "ORGANİK",
    "Kullandığımız tüm malzemeler% 100 organik ve tazedir. Bu yaklaşım yemeğimizi çok daha sağlıklı hale getiriyor.",
    "LEZZETLİ",
    "Yemeklerimizin harika ve unutulmaz tadı, giderek daha fazla müşteriyi Tabağa çeken şeydir",
    "ÇEŞİTLİ",
    "Ekibimiz, sipariş verdiğinizde size daha iyi yiyecek çeşitliliği sağlamak için menüleri düzenli olarak günceller",
  ];
  fraturesTexts.forEach((element, index) => {
    element.textContent = fraturesTextsTrTexts[index];
  });

  /* TRANSLATE WHAT OUR CLIENTS SAY */
  const ClientsTexts = document.querySelectorAll(".clients_txt");
  const ClientsTextsTrTexts = [
    "MÜŞTERİLERİMİZ NE DİYOR",
    "REFERANSLAR",
    "Çok fazla yemek dağıtım hizmeti denedim ama Plate bu dünyanın dışında bir şey! Yemekleri gerçekten sağlıklı ve tadı harika, bu yüzden bu şirketi tüm arkadaşlarıma tavsiye ediyorum!",
    "Hem yemekler hem de müşteri hizmetleriniz her açıdan mükemmel ve sadece şirketinizden ne kadar mutlu olduğumu ifade etmek istedim. Size en iyisini diliyorum!",
    "Dengeli menünüz için çok teşekkür ederim, bana çok yardımcı oldu ve sizden yediğim yemeğin bağışıklık sistemimi güçlendirmeye gerçekten yardımcı olduğunu hissediyorum.",
  ];
  ClientsTexts.forEach((element, index) => {
    element.textContent = ClientsTextsTrTexts[index];
  });

  const SendReviewTexts = document.querySelectorAll(".btn_send_review");
  const SendReviewTextsTrText = ["YORUMUNUZU GÖNDERİN"];
  SendReviewTexts.forEach((element, index) => {
    element.textContent = SendReviewTextsTrText[index];
  });

  /* TRANSLATE FOOTER */
  const footerTexts = document.querySelectorAll(".footer_txt");
  const footerTextsTrTexts = [
    "© 2024 Plate. tüm hakları saklıdır",
    "İLETİŞİM",
    "Tel.",
    "E-posta.",
    "HIZLI LİNKLER",
    "Nasıl Çalışır",
    "Hakkımızda",
    "Neden Bizi Seçmelisiniz",
    "GIDA PAKETLERİ",
    "Detoks",
    "Dengeli",
    "Vegan",
  ];
  footerTexts.forEach((element, index) => {
    element.textContent = footerTextsTrTexts[index];
  });

  /* FORM TRANSLATE */
  const formTexts = document.querySelectorAll(".form_txt");
  const formTextsTrTexts = [
    "SİPARİŞİNİ TAMAMLA",
    "Bir Gıda Paketi Seçin",
    "Detoks",
    "Dengeli",
    "Vegan",
  ];
  formTexts.forEach((element, index) => {
    element.textContent = formTextsTrTexts[index];
  });

  const inputTexts = document.querySelectorAll(".input_txt");
  const inputTextsTrTexts = ["E-posta", "Telefon", "Yorum"];
  inputTexts.forEach((element, index) => {
    element.placeholder = inputTextsTrTexts[index];
  });
}

/*---------- TRANSLATE TO ARABIC ----------*/

function settingsToArabic() {
  /* NAVBAR SECTION SETTINGS */
  const headerLogo = document.querySelector(".header_logo");
  if (headerLogo) {
    headerLogo.style.marginRight = "22rem";
    headerLogo.style.marginLeft = "0";
  }

  /* SLIDER SECTION SETTINGS */
  const imageSections = document.querySelectorAll(".image-section");
  imageSections.forEach((element) => {
    element.style.marginLeft = "20rem";
    element.style.marginRight = "0";
  });

  const circle = document.querySelector(".circle");
  if (circle) {
    circle.style.transform = "translate(-45%, -5%)";
  }

  const textSections = document.querySelectorAll(".text-section");
  textSections.forEach((element) => {
    element.style.paddingRight = "20rem";
    element.style.paddingLeft = "0";
  });

  const texts = document.querySelectorAll(".texts");
  texts.forEach((element) => {
    element.style.paddingLeft = "0";
    element.style.textAlign = "right";
  });

  const sliderTitles = document.querySelectorAll(".h2_text");
  sliderTitles.forEach((element) => {
    element.style.textAlign = "right";
  });

  const dots = document.querySelectorAll(".dot");
  dots.forEach((dot) => {
    dot.style.transform = "translate(50%, 50%)";
  });

  const navigation = document.querySelector(".navigation");
  if (navigation) {
    navigation.style.paddingLeft = "0";
    navigation.style.justifyContent = "flex-start";
  }

  /* ABOUT US SECTION SETTINGS */
  const aboutUsTxtItems = document.querySelectorAll(".about_us_texts li");
  aboutUsTxtItems.forEach((item) => {
    item.style.paddingRight = "35px";
    item.style.paddingLeft = "0";
  });

  const style = document.createElement("style");
  style.innerHTML = `
  .about_us_texts li::before {
    left: auto;
    right: 0;
  }
`;
  document.head.appendChild(style);

  /* WHAT WE OFFER SETTINGS */
  const whatImgItems = document.querySelectorAll(".what_img");
  whatImgItems.forEach((item) => {
    item.style.transform = "translate(-90%, -60%)";
  });

  /* HOW IT WORKS SETTINGS */
  const rowDivs = document.querySelectorAll(".row");
  rowDivs.forEach((div) => {
    const svg = div.querySelector("svg");
    if (svg) {
      svg.style.transform = "scaleX(-1)";
    }
  });

  const howDotItems = document.querySelectorAll(".how_dot");
  howDotItems.forEach((item) => {
    item.style.transform = "translate(100%, -80%)";
  });

  /* FEATURES SECTION SETTINGS */
  const positionImg1 = document.querySelector(".position_img_1");
  if (positionImg1) {
    positionImg1.style.transform = "translate(-20%, 30%)";
  }

  const positionImg2 = document.querySelector(".position_img_2");
  if (positionImg2) {
    positionImg2.style.transform = "translate(-80%, 50%)";
  }

  const positionImg3 = document.querySelector(".position_img_3");
  if (positionImg1) {
    positionImg3.style.transform = "translate(0%, 15%)";
  }

  const positionImg4 = document.querySelector(".position_img_4");
  if (positionImg4) {
    positionImg4.style.transform = "translate(-80%, 50%)";
  }

  /* WHAT OUR CLIENTS SAY SECTION SETTINGS */
  const dashes = document.querySelector(".dashes");
  if (dashes) {
    dashes.style.marginRight = "5rem";
    dashes.style.marginLeft = "0";
  }

  const clientsSay = document.querySelector(".clients_say");
  if (clientsSay) {
    clientsSay.style.gap = "75px";
  }

  const clientsTitles = document.querySelector(".clients_titles");
  if (clientsTitles) {
    clientsTitles.style.padding = "70px";
  }

  /* FOOTER SECTION SETTINGS */
  const phoneLiItems = document.querySelectorAll(".phone li");
  phoneLiItems.forEach((item) => {
    item.style.marginLeft = "20px";
    item.style.marginRight = "0";
  });

  const mailLiItems = document.querySelectorAll(".mail li");
  mailLiItems.forEach((item) => {
    item.style.marginLeft = "14px";
    item.style.marginRight = "0";
  });

  /* FORM SECTION SETTINGS */
  const toggleButton = document.querySelector(".toggleButton");
  if (toggleButton) {
    toggleButton.style.transform = "translate(-2550%, 100%)";
  }

  const formContainer = document.querySelector(".formContainer");
  if (formContainer) {
    formContainer.style.right = "auto";
    formContainer.style.left = "0";
    formContainer.style.transform = "translateX(-100%)";
    formContainer.style.transition = "transform 0.5s ease";
  }

  toggleButton.addEventListener("click", () => {
    if (formContainer.style.transform === "translateX(-100%)") {
      formContainer.style.transform = "translateX(0)";
    } else {
      formContainer.style.transform = "translateX(-100%)";
    }
  });

  const formInputs = document.querySelectorAll("input, textarea");
  formInputs.forEach((input) => {
    input.style.direction = "rtl";
  });

  /* DARK MODE SETTINGS */
  const darkModeButton = document.querySelector(".dark");
  if (darkModeButton) {
    darkModeButton.style.transform = "translate(-2550%, -100%)";
  }
}

function translateToArabic() {
  /* TRANSLATE NAVBAR */
  const navSpans = document.querySelectorAll(".nav_span");
  const navSpansTrTexts = ["برامج", "من نحن", "العملاء"];
  navSpans.forEach((element, index) => {
    element.textContent = navSpansTrTexts[index];
  });

  /* TRANSLATE SLIDER */
  const sliderTexts = document.querySelectorAll(".texts");
  const sliderTextstrTexts = [
    "مرحبا بكم في بليت",
    "بليت تقدم خدمة التوصيل السريع للأطعمة العضوية والصحية إلى جميع أنحاء العالم.",
    "لماذا يجب عليك اختيار بليت",
    "توصيل على مستوى البلد",
    "لراحتكم، خدمة توزيع الطعام متوفرة في أكثر من 200 مدينة.",
    "توصيل على مستوى البلاد",
    "أفضل الأطعمة والمكونات",
    "بليت تحدث قوائم الطعام بانتظام للتأكد من أن عملائنا يتناولون أفضل وألذ الأطعمة.",
    "مواد عضوية",
    "عملاؤنا يثقون بنا",
    "تعليقات عملائنا هي أفضل طريقة لمعرفة المزيد عن خدمة توزيع الطعام لدينا.",
    "التعليقات والآراء",
  ];
  sliderTexts.forEach((element, index) => {
    element.textContent = sliderTextstrTexts[index];
  });

  const slidertitles = document.querySelectorAll(".h2_text");
  const slidertitlesTrTexts = [
    "خدمة التوصيل",
    "المواقع المدعومة",
    "أطعمة لذيذة",
    "مراجعات إيجابية",
  ];
  slidertitles.forEach((element, index) => {
    element.textContent = slidertitlesTrTexts[index];
  });

  /* TRANSLATE ABOUT US */
  const aboutUsText = document.querySelectorAll(".about_us_txt");
  const aboutUsTextTrTexts = [
    "من نحن",
    "يمكن أن تكون الأطعمة الصحية لذيذة",
    "تأسست بليت في عام 2013 كمزود خدمة طعام موثوق به حيث يمكن للجميع طلب الأطعمة الصحية التي يرغبون بها.",
    "اختر أطعمة خالية من الغلوتين من قائمتنا",
    "أحدث المكونات لكل وجبة",
    "احصل على خصومات رائعة عند الطلب لأكثر من شخصين",
  ];
  aboutUsText.forEach((element, index) => {
    element.textContent = aboutUsTextTrTexts[index];
  });

  const readMoreBtnText = document.querySelectorAll(".read_more_btn");
  const readMoreBtnTextTrText = [
    "المزيد",
    "المزيد",
    "المزيد",
    "المزيد",
    "المزيد",
  ];
  readMoreBtnText.forEach((element, index) => {
    element.textContent = readMoreBtnTextTrText[index];
  });

  /* TRANSLATE WHAT WE OFFER */
  const whatTexts = document.querySelectorAll(".what_txt");
  const whatTextsTrTexts = [
    "منتجاتما",
    "الوجبات",
    "ديتوكس",
    "يوميا",
    "إذا كنت تبحث عن أطعمة لذيذة وخفيفة ولكن صحية لبدء يومك مليئًا بالطاقة، فهذا هو الاختيار الأفضل.",
    "متوازن",
    "يوميا",
    "إذا كنت بحاجة إلى قائمة يومية متوازنة تشمل وجبة الفطور ووجبة العشاء، فستجد لدينا ما تحتاجه!",
    "نباتي",
    "يوميا",
    "تم تطوير قائمة خاصة لعملائنا النباتيين الذين يقدرون الأطعمة الصحية والمستندة إلى النباتات.",
  ];
  whatTexts.forEach((element, index) => {
    element.textContent = whatTextsTrTexts[index];
  });

  const readMorePdf = document.querySelectorAll(".read_more_pdf");
  const readMorePdfTrTexts = [
    "افتح القائمة (PDF)",
    "افتح القائمة (PDF)",
    "افتح القائمة (PDF)",
  ];
  readMorePdf.forEach((element, index) => {
    element.textContent = readMorePdfTrTexts[index];
  });

  /* TRANSLATE HOW IT WORKS */
  const howTexts = document.querySelectorAll(".how_txt");
  const howTextsTrTexts = [
    "كيف تعمل",
    "ثلاث خطوات لتناول الطعام الصحي",
    "اختار وجبة",
    "أولاً، اختر الوجبة المفضلة لديك",
    "خصص قائمتك",
    "بعد ذلك، لا تتردد في تعديل قائمتك وتخصيصها.",
    "اختر عنوان ووقت التوصيل",
    "أخيرًا، أخبرنا بمكان ووقت تسليم وجبتك.",
  ];
  howTexts.forEach((element, index) => {
    element.textContent = howTextsTrTexts[index];
  });

  /* TRANSLATE FEATURES */
  const fraturesTexts = document.querySelectorAll(".features_txt");
  const fraturesTextsTrTexts = [
    "جودة",
    "نعمل مع أفضل الموردين للتأكد من أنك تحصل على أفضل جودة في الأطعمة والمشروبات والخدمات.",
    "صحي",
    "جميع المكونات التي نستخدمها هي عضوية وطازجة بنسبة 100٪، وهذا النهج يجعل طعامنا أكثر صحة.",
    "لذيذ",
    "طعم أطباقنا الرائع واللافت للنظر هو ما يجذب المزيد من الزبائن إلى بليت",
    "متنوع",
    "فريقنا يقوم بتحديث القوائم بانتظام لتوفير تشكيلة متنوعة وأفضل لك عند طلب الطعام.",
  ];
  fraturesTexts.forEach((element, index) => {
    element.textContent = fraturesTextsTrTexts[index];
  });

  /* TRANSLATE WHAT OUR CLIENTS SAY */
  const ClientsTexts = document.querySelectorAll(".clients_txt");
  const ClientsTextsTrTexts = [
    "عملاؤنا يقولون",
    "مراجعيات",
    "لقد جربت العديد من خدمات توصيل الطعام، ولكن بليت هو شيء آخر تمامًا! الطعام لذيذ وصحي حقًا، لذا أنصح بهذه الشركة لكل أصدقائي!",
    "الأطعمة وخدمة العملاء في شركتكم ممتازة بكل المقاييس، وأردت فقط أن أعبر عن سعادتي الكبيرة بهذا. أتمنى لكم كل التوفيق!",
    "شكرًا جزيلاً على القائمة المتوازنة، ساعدتني كثيرًا وأشعر بأن الطعام الذي تناولته منكم ساعد في تعزيز جهاز المناعة لدي بالفعل.",
  ];
  ClientsTexts.forEach((element, index) => {
    element.textContent = ClientsTextsTrTexts[index];
  });

  const SendReviewTexts = document.querySelectorAll(".btn_send_review");
  const SendReviewTextsTrText = ["ارسل تعليق"];
  SendReviewTexts.forEach((element, index) => {
    element.textContent = SendReviewTextsTrText[index];
  });

  /* TRANSLATE FOOTER */
  const footerTexts = document.querySelectorAll(".footer_txt");
  const footerTextsTrTexts = [
    "© 2024 بليت. جميع الحقوق محفوظة.",
    "التواصل",
    "هاتف",
    "بريد",
    "روابط سريعة",
    "كيف تعمل",
    "من نحن",
    "لماذا يجب عليك اختيارنا",
    " وجبات الطعام",
    "ديتوكس",
    "متوازن",
    "نباتي",
  ];
  footerTexts.forEach((element, index) => {
    element.textContent = footerTextsTrTexts[index];
  });

  /* FORM TRANSLATE */
  const formTexts = document.querySelectorAll(".form_txt");
  const formTextsTrTexts = [
    "أكمل الطلب",
    "اختار وجبة",
    "ديتوكس",
    "متوازن",
    "نباتي",
  ];
  formTexts.forEach((element, index) => {
    element.textContent = formTextsTrTexts[index];
  });

  const inputTexts = document.querySelectorAll(".input_txt");
  const inputTextsTrTexts = ["بريد إلكتروني", "هاتف", "تعليق"];
  inputTexts.forEach((element, index) => {
    element.placeholder = inputTextsTrTexts[index];
  });
}

/* LANGUAGE SELECTION */
document.addEventListener("DOMContentLoaded", () => {
  const languageToggles = document.querySelectorAll('input[name="language"]');
  const container = document.querySelector(".container");
  const formContainer = document.querySelector(".formContainer");

  container.classList.remove("tr", "ar");

  languageToggles.forEach((toggle) => {
    toggle.addEventListener("change", (event) => {
      const selectedLanguage = event.target.value;

      if (selectedLanguage === "tr") {
        container.classList.remove("ar");
        container.classList.add("tr");
        document.documentElement.removeAttribute("dir");
        settingsToTurkish();
        translateToTurkish();
      } else if (selectedLanguage === "ar") {
        container.classList.remove("tr");
        container.classList.add("ar");
        document.documentElement.setAttribute("dir", "rtl");
        formContainer.classList.remove("show");
        settingsToArabic();
        translateToArabic();
      } else {
        container.classList.remove("tr", "ar");
        document.documentElement.removeAttribute("dir");
        location.reload();
      }
    });
  });
});
