/* Load */
window.onload = function () {
  window.scrollTo(0, 0);
};

/* Fixed navbar */
window.onscroll = () => {
  const navbar = document.querySelector(".header_container");
  const sticky = 250;

  navbar.classList.toggle("fixed", window.pageYOffset > sticky);
};

/* Slider */
document.addEventListener("DOMContentLoaded", function () {
  const sliderItems = document.querySelectorAll(".slider-item");
  const allNumbers = document.querySelectorAll(".numbers");

  allNumbers.forEach((number, index) => {
    number.addEventListener("click", () => {
      document
        .querySelectorAll(".active")
        .forEach((el) => el.classList.remove("active"));

      number.classList.add("active");
      sliderItems[index % sliderItems.length].classList.add("active");

      for (let i = index % 4; i < allNumbers.length; i += 4) {
        allNumbers[i].classList.add("active");
      }
    });
  });
});

/* Client Sat Slider */
document.addEventListener("DOMContentLoaded", function () {
  const images = document.querySelectorAll(".clients_img_container img");
  const clients = document.querySelectorAll(".clients_slider");
  const dashes = document.querySelectorAll(".dash");

  function activateSlide(index) {
    clients.forEach((client, idx) => {
      client.classList.toggle("show", idx === index);
    });

    dashes.forEach((dash, idx) => {
      dash.classList.toggle("active", idx === index);
    });

    images.forEach((img, idx) => {
      img.classList.toggle("active_img", idx === index);
    });
  }

  images.forEach((img, index) => {
    img.addEventListener("click", () => activateSlide(index));
  });

  dashes.forEach((dash, index) => {
    dash.addEventListener("click", () => activateSlide(index));
  });

  activateSlide(0);
});

/* Dark Mode */
document.querySelector(".dark button").addEventListener("click", function () {
  const container = document.querySelector(".dark");
  container.classList.toggle("active");
  document.body.classList.toggle("sun-active");

  const [moonIcon, sunnyIcon] = container.querySelectorAll(".moon, .sunny");
  moonIcon.style.display = container.classList.contains("active")
    ? "none"
    : "block";
  sunnyIcon.style.display = container.classList.contains("active")
    ? "block"
    : "none";

  const icon = this.querySelector("ion-icon");
  icon.setAttribute(
    "name",
    document.body.classList.contains("sun-active")
      ? "sunny-outline"
      : "moon-outline"
  );
});

document.querySelector(".toggleButton").addEventListener("click", function () {
  var formContainer = document.querySelector(".formContainer");
  if (formContainer.classList.contains("hidden")) {
    formContainer.classList.remove("hidden");
    formContainer.classList.add("show");
    this.innerHTML = '<ion-icon class="close" name="close-outline"></ion-icon>';
  } else {
    formContainer.classList.remove("show");
    formContainer.classList.add("hidden");
    this.innerHTML =
      '<ion-icon class="mail_open" name="mail-open-outline"></ion-icon>';
  }
});

/* BUTON WORKING */

function loadProductPage() {
  // window.location.href = "products.html";
  window.open("products.html", "_blank");
}
